/* run.config
   OPT: tests/cil/merge2.c -print
*/
int x;
