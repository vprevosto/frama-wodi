int y,z;
void main(int x) {
  if(z++) ;
  return;
}
