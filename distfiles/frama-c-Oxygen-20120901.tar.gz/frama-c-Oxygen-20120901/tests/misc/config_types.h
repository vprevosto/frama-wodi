
#define false 0
#define true 1
#define bool int
#define _int int
#define real float

