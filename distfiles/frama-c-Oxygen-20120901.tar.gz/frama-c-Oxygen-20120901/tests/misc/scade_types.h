/*$************* SCADE_KCG KCG Version 5.1.1 (build i10) **************
** Command :
** l2C        CruiseControl.lus -node CruiseControl
**     -noexp @ALL@
**     -keep_named_var
**     -const
**     -bitwise
**     -loc_ctx
**     -no_copy_mem
**     -debug
** date of generation (MM/DD/YYYY): 07/06/2007 13:30:09
** last modification date for CruiseControl.lus (MM/DD/YYYY): 07/06/2007 
********************************************************************$*/

/* ===== */
/* TYPES */
/* ===== */

#include "config_types.h"

#define _INCLUDE_SCADE_TYPES

typedef real Percent;

typedef real Speed;





/*$************* SCADE_KCG KCG Version 5.1.1 (build i10) **************
** End of file scade_types.h
** End of generation (MM/DD/YYYY) : 07/06/2007 13:30:09
********************************************************************$*/
