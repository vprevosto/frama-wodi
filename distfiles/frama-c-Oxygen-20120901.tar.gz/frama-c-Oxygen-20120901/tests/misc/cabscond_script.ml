
let () = Cabscond.active := true
let () = Db.Main.extend Cabsbranches.compute
