int main () {
  //@ ghost int x = 0;
  //@ ghost x++;
  return 0;
}

//@ ghost int G;
