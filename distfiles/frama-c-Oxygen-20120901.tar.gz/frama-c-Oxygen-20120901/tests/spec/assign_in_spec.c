

//@ ensures \result = 1;
int f();

