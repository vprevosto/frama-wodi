/* run.config
   STDOPT: +"tests/spec/axiom_included_1.c"
*/

#include "tests/spec/axiom_included.h"
