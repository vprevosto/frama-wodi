/*@ logic char* foo = "\123tyfoo";

    logic unsigned long* bar = (unsigned long*) L"\xabcdt\65ab";

    logic char* split = "abc" "def";

 */

unsigned long* test = (unsigned long*)  L"\xabcdt\65ab";
