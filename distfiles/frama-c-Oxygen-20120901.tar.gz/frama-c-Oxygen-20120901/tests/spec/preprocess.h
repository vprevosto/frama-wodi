#define MIN_X 42

//@ predicate test(int x) = x >= MIN_X ;
