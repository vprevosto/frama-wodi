/*@ ensures "/*"[0] == '/'; */
char f(void) { return "/*"[1]; }
