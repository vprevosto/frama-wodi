/* run.config
   DONTRUN: main test is in axiom_included.c
*/

#include "tests/spec/axiom_included.h"
