/*@ logic int f (int i); */
