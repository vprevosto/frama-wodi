/* run.config
   EXECNOW: make -s tests/slicing2/adpcm.opt
   CMD: tests/slicing2/adpcm.opt
   OPT: -check -no-annot -deps -slicing-level 2 -journal-disable
*/

#include "tests/test/adpcm.c"
