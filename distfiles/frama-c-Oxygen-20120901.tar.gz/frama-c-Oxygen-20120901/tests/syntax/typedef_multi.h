typedef int WORD;

extern WORD x,y;
