let () =
  Db.Main.extend Allocates.add_allocates_nothing
